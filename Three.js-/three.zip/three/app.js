var scene, camera, renderer, controls;
var waypoint = false;

    scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);
      
const backMatry = new THREE.SphereGeometry(5, 100, 100, 100);
var textured = new THREE.TextureLoader().load('./back.jpg');
    const backmaterial = new THREE.MeshBasicMaterial({
        // color: 0xf00000,
        // wireframe: true,
        side:THREE.BackSide,
    map: textured
       
    });
    const galaxy = new THREE.Mesh( backMatry, backmaterial );
scene.add(galaxy);
// galaxy.position.x = 10;

    var texture = new THREE.TextureLoader().load('./map.jpg');
    // var geometry = new THREE.BoxGeometry(1, 1, 1);
    // var material = new THREE.MeshBasicMaterial({ });
    // var cube = new THREE.Mesh(geometry, material);
    // scene.add(cube);

    var sphereGeo = new THREE.SphereBufferGeometry(1, 66, 66);
var sphereMat = new THREE.MeshBasicMaterial({
    map: texture,
    color: 0xff0000,
});
    var sphere = new THREE.Mesh(sphereGeo, sphereMat);
    scene.add(sphere);

    camera.position.z = 5;

    controls = new THREE.OrbitControls(camera);


var animate = function () {

    requestAnimationFrame(animate);
    // cube.rotation.x += 001;
    controls.update();
    sphere.rotation.y += 0.01;
    galaxy.rotation.y += -0.001;
    renderer.render(scene, controls.object);

};




animate();